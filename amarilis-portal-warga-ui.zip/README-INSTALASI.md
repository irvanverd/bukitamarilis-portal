# Tampilan Portal Penghuni — MyAmarilis

Paket ini merupakan **overlay tambahan** untuk project Next.js Portal Bukit Amarilis, bukan pengganti seluruh repository.

## Yang ditambahkan

- `/portal-warga` — ringkasan total tagihan IPL saat ini.
- **Unit saya** — nama penghuni, nomor blok/unit, luas rumah, tarif IPL, dan preview pemilihan foto rumah.
- **Riwayat IPL** — enam baris tagihan contoh, termasuk lunas dan belum lunas.
- **Komplain** — form simulasi dan daftar laporan dummy.
- **Surat Pengantar** — form simulasi dan status permohonan dummy.
- Navigasi sidebar desktop dan bottom navigation untuk ponsel.

## Cara memasang

1. Backup project terlebih dahulu.
2. Ekstrak seluruh isi ZIP langsung ke folder `web/` (root Next.js). Struktur file di ZIP sudah dibuat sesuai folder project.
3. Izinkan replace `components/Navbar.tsx` dan `components/Footer.tsx`. Navbar di paket ini mempertahankan menu **Daftar Penghuni** dari tahap sebelumnya.
4. Jalankan `npm run dev`, kemudian buka `http://localhost:3000/portal-warga`.
5. Setelah pengujian, deploy ke Vercel seperti biasa.

## Batasan penting pada tahap ini

- Semua nama, tagihan, tarif, unit, riwayat IPL, komplain, dan surat pada halaman ini adalah **data dummy**.
- Form komplain dan surat hanya menambahkan data ke state halaman/browser; tidak menyimpan ke Google Sheets dan tidak mengirim permohonan ke pengurus.
- Foto rumah hanya preview di browser. File foto belum diunggah atau disimpan ke server.
- Route `/portal-warga` **belum dibatasi dengan autentikasi penghuni** pada paket UI ini. Karena itu, jangan masukkan data warga asli atau menganggap halaman ini sudah siap dipakai untuk data produksi. Tahap berikutnya adalah membuat login penghuni yang sudah disetujui admin, melindungi route dengan session cookie, lalu mengganti dummy dengan endpoint Apps Script/Sheet IPL.
- Paket ini tidak mengubah `Code.gs` dan tidak membuat API data IPL baru.
